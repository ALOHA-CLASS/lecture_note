# 1
data (iris)


# 2
ls (iris)
nrow (iris)


# 3
quantile (iris$Sepal.Length, probs = 0.25 )
quantile (iris$Sepal.Length, probs = 1 )