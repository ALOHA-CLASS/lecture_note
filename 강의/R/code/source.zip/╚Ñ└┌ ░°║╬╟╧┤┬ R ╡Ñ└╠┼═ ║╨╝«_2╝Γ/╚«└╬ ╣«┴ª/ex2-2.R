# 3
ID <- c("1", "2", "3", "4", "5")
MID_EXAM <- c(10, 25, 100, 75, 30)
CLASS <- c("1반", "2반", "3반", "1반", "2반")


# 4
example_test <- data.frame(ID, MID_EXAM, CLASS)
example_test