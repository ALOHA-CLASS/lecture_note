# 3
install.packages("reshape2")


# 4
library(reshape2)