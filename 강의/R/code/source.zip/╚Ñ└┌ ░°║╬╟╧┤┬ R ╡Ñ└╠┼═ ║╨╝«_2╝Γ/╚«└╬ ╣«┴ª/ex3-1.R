# 4
x <- c(1, 3, 5, 7, 9)
x


# 5
y <- "Hello"
y


# 6
num_three_return <- function(x, y, z) {
  sum <- x + y + z
  return(sum)
}
num_three_return(10, 20, 30)