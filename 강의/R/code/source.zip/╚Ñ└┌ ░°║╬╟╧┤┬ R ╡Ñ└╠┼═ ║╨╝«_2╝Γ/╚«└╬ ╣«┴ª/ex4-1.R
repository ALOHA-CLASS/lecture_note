# 3, 4, 6번 문제는 단순 빈칸 채우기 문제이므로 예제 파일을 제공하지 않습니다.

# 5
install.packages('readxl')
library(readxl)


# 7
install.packages("jsonlite")
library(jsonlite)